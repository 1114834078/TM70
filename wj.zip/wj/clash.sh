source /etc/profile
/usr/share/clash/clash.sh -s start